package tdas.interfaces;

public interface Sizeable {

	int size();

}