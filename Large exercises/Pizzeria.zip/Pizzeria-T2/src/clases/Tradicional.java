package clases;

public class Tradicional extends Pizza {
	private TipoDeMasa masa;

	public Tradicional(String nombre, float costoDeProduccion, float porcentajeGanancia, TipoDeMasa masa) {
		super(nombre, costoDeProduccion, porcentajeGanancia);
		this.masa = masa;
	}

	@Override
	public Float getPrecioDeCosto() {
		return this.getCostoDeProduccion() * this.masa.getPorcentaje();
	}

	@Override
	public TipoPizza tipo() {
		return TipoPizza.TRADICIONAL;
	}
	
	@Override
	public void mostrar() {
		System.out.printf("%s - %s - Precio de venta: %f - %s", this.tipo().name(), 
				this.getNombre(), this.getPrecioDeVenta(), this.masa.getDescripcion());
		System.out.println();	
	}
	
	
}
