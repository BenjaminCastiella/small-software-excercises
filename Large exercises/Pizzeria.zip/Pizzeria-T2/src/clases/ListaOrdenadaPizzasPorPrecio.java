package clases;

import tdas.implementaciones.ListaOrdenadaNodos;

public class ListaOrdenadaPizzasPorPrecio extends ListaOrdenadaNodos<Float, Pizza>{

	@Override
	public int compare(Pizza p1, Pizza p2) {
		return -1 * p1.getPrecioDeVenta().compareTo(p2.getPrecioDeVenta());
	}

	@Override
	public int compareByKey(Float precioP1, Pizza p2) {
		return -1 * precioP1.compareTo(p2.getPrecioDeVenta());
	}

	
}
