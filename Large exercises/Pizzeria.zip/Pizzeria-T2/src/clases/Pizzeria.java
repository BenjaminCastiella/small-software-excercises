package clases;

import tdas.implementaciones.ListaOrdenadaNodos;
import tdas.implementaciones.PilaNodos;

public class Pizzeria  implements Mostrable{
	private static final String MSG_PIZZA_TOPPINGS_NULO = "No se pudo fabricar Pizza o Topping nulo.";
	private static final String MSG_TOPPINGS = "Error de par�metros incorporando toppings";
	private static final String MSG_TOTALES = "La venta total fue: $%8.2f\n";
	private static final String MSG_CANTIDADES = "Se han fabricado: %d Tradicionales, %d Especiales y %d Rectangulares\n";
	private String nombre;
	private PilaNodos<Exception> pilaDeExcepciones;
	private ListaOrdenadaPizzasPorPrecio listaOrdDePizzas;
	private int[][] tipoPizzaXToppings;
	
	public Pizzeria(String nombre) {
		this.nombre = nombre;
		this.pilaDeExcepciones = new PilaNodos<Exception>();
		this.listaOrdDePizzas = new ListaOrdenadaPizzasPorPrecio();
		this.tipoPizzaXToppings = new int[TipoPizza.values().length][Topping.values().length];
	}

	public void incorporarTopping(TipoPizza tipoPizza, Topping topping, int cantidad) {
		this.tipoPizzaXToppings[tipoPizza.ordinal()][topping.ordinal()] = cantidad;
	}

	public void ingresarPedido(Pizza p, Topping topping) throws Exception{
		Exception excp;
		
		if(p == null) {
			excp = new Exception("la Pizza no puede ser nula");
			this.pilaDeExcepciones.push(excp);
			throw excp;
		}
		if(topping == null) {
			excp = new Exception("El topping no puede ser nulo");
			this.pilaDeExcepciones.push(excp);
			throw excp;
		}
		
		if(this.tipoPizzaXToppings[p.tipo().ordinal()][topping.ordinal()] < 1) {
			excp = new Exception("No hay más toppings disponibles para esa pizza");
			this.pilaDeExcepciones.push(excp);
			throw excp;
		}
		
		this.listaOrdDePizzas.add(p);
	}
	
	@Override
	public void mostrar() {
		for(int i = 0; i < this.listaOrdDePizzas.size(); i++) {
			this.listaOrdDePizzas.get(i).mostrar();
		}
	}
	
	public float importeTotalVentasPorNombrePizza(String nombrePizza) {
		float result = 0;
		for(int i = 0; i < this.listaOrdDePizzas.size(); i++) {
			if(this.listaOrdDePizzas.get(i).mismoNombre(nombrePizza)) {
				result += this.listaOrdDePizzas.get(i).getPrecioDeVenta();
			}
		}
		
		return result;
	}

}
