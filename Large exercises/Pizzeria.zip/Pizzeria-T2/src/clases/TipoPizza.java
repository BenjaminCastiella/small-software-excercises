package clases;

public enum TipoPizza {
	ESPECIAL, TRADICIONAL, RECTANGULAR;
}
