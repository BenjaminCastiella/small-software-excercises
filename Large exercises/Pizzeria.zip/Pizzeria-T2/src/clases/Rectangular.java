package clases;

public class Rectangular extends Pizza {
	private static final int PRECIO_PORCION = 52;
	private int largoPorciones;
	private int anchoPorciones;
	private AdicionalQueso quesoAdd;
	
	public Rectangular(String nombre, float costoDeProduccion, float porcentajeGanancia, int largoPorciones,
	int anchoPorciones, AdicionalQueso quesoAdd) {
		super(nombre, costoDeProduccion, porcentajeGanancia);
		this.largoPorciones = largoPorciones;
		this.anchoPorciones = anchoPorciones;
		this.quesoAdd = quesoAdd;
	}

	@Override
	public Float getPrecioDeCosto() {
		return (this.getCostoDeProduccion() + (this.largoPorciones * this.anchoPorciones) * PRECIO_PORCION) * quesoAdd.getMultiplicadorQueso();
	}

	@Override
	public TipoPizza tipo() {
		return TipoPizza.RECTANGULAR;
	}
	
	@Override
	public void mostrar() {
		System.out.printf("%s - %s - Precio de venta: %f - %d porciones - %s", this.tipo().name(), 
				this.getNombre(), this.getPrecioDeVenta(), (this.anchoPorciones * this.largoPorciones), this.quesoAdd.name());
		System.out.println();	
	}
}
