package clases;

public interface Mostrable {
	void mostrar();
}
