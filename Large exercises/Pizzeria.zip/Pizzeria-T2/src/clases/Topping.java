package clases;

public enum Topping {

	TOMATE("Tomate"), JAMON("Jamon"), MORRON("Morron"), CEBOLLA("Cebolla"), SALAMIN("Salamon");
	
	private String nombre;
	
	private Topping(String nombre) {
		this.nombre = nombre;
	}

	public String getNombre() {
		return this.nombre;
	}
}
