package clases;

public class Especial extends Pizza {
	private static final int PRECIO_FAINA = 38;
	private TamanioDePizza tamanio;
	private int cantFaina;
	
	public Especial(String nombre, float costoDeProduccion, float porcentajeGanancia, TamanioDePizza tamanio,
	int cantFaina) {
		super(nombre, costoDeProduccion, porcentajeGanancia);
		this.tamanio = tamanio;
		this.cantFaina = cantFaina;
	}

	@Override
	public Float getPrecioDeCosto() {
		return this.getCostoDeProduccion() * this.tamanio.getPorcentaje() + this.cantFaina * PRECIO_FAINA;
	}

	@Override
	public TipoPizza tipo() {
		return TipoPizza.ESPECIAL;
	}
	
	@Override
	public void mostrar() {
		System.out.printf("%s - %s - Precio de venta: %f - %d Fainas - %s", this.tipo().name(), 
				this.getNombre(), this.getPrecioDeVenta(), this.cantFaina, this.tamanio.name());
		System.out.println();	
	}
}
