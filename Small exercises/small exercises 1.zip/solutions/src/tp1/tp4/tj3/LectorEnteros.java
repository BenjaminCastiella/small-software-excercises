package tp1.tp4.tj3;

import java.time.Year;
import java.util.InputMismatchException;
import java.util.Scanner;

public class LectorEnteros {
	private static final String MENSAJE_ERROR_SCANNER_NULL = "Debe recibirse un Scanner.";
	private static final String MENSAJE_CARGA_ENTERO = "Ingrese un numero entero cualquiera";
	private static final String MENSAJE_FUERA_DE_RANGO = "El valor ingresado esta fuera del rango aceptable";
	private Scanner scanner;
	
	public LectorEnteros(Scanner scanner) {
		setScanner(scanner);
	}

	public void setScanner(Scanner scanner) {
		try {
			this.scanner = scanner;			
		} catch(InputMismatchException e) {
			throw new IllegalArgumentException("Error, " + MENSAJE_ERROR_SCANNER_NULL);
		}
	}


	private int cargar(String mensaje) {
		int num = 0;
		System.out.println(mensaje);
		try {
			num = Integer.parseInt(scanner.nextLine());
		} catch(NumberFormatException e) {
			throw new IllegalArgumentException("Error, no ha ingresado un numero con el formato correcto");
		}
		
		return num;
	}
	

	public int pedir(String mensaje) {
		int num;
		num = cargar(mensaje);
		return num;
	}

	public int pedir(String mensaje, int limiteA, int limiteB){
		int num = cargar(mensaje + ". Ingrese el nro deseado entre los valores " + limiteA + " y " + limiteB);
		if(limiteA > limiteB) {
			if(num > limiteA || num < limiteB) {
				throw new IllegalArgumentException("Error, " + MENSAJE_FUERA_DE_RANGO);
			} else {
				System.out.println("Todo ok!");
			}
		} else if(limiteA < limiteB) {
			if(num < limiteA || num > limiteB) {
				throw new IllegalArgumentException("Error, " + MENSAJE_FUERA_DE_RANGO);
			} else {
				System.out.println("Todo ok!");
			}
		}
		
		return num;
	}

	public int pedir(String mensaje, RangoDeEnteros rangoValido){
		if(mensaje == null && rangoValido == null) {
			throw new IllegalArgumentException("Error, los parametros no pueden ser nulos.");
		}
		
		int rangoInf = rangoValido.getLimiteInferior();
		int rangoSup = rangoValido.getLimiteSuperior();
		int num;
		
		if (mensaje == "") {
			num = cargar(MENSAJE_CARGA_ENTERO + ". Ingrese el nro deseado entre los valores " + rangoInf + " y " + rangoSup);
		} else {
			num = cargar(mensaje + ". Ingrese el nro deseado entre los valores " + rangoInf + " y " + rangoSup);
		}
		
		if(num < rangoInf || num > rangoSup) {
			throw new IllegalArgumentException("Error, " + MENSAJE_FUERA_DE_RANGO);
		}
		
		return num;
	}
}
