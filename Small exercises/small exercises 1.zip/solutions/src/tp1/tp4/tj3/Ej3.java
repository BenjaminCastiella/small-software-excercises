package tp1.tp4.tj3;

import java.util.Scanner;

import tp1.tp4.ej2.Alumno;
import tp1.tp4.ej2.Persona;

public class Ej3 {
	public static void main(String[] args) {
		String nombre;
		int nacimiento;
		int fallecimiento;
		int dni;
		Scanner input = new Scanner(System.in);
		LectorEnteros lector = new LectorEnteros(input);
		Persona alumno;
		
		System.out.println("Ingresá el nombre del alumno");
		nombre = input.nextLine(); //Carlitos Tevez
		nacimiento = lector.pedir("Ingresá la fecha de nacimiento del alumno"); //1985
		fallecimiento = lector.pedir("Ingresá la fecha de fallecimiento del alumno o -1 o -9999 en caso de que siga vivo."); // -
		dni = lector.pedir("Ingresá su dni");
		alumno = new Alumno(nombre, nacimiento, fallecimiento, dni); //1000001
		
		
		System.out.println(alumno.toString());
		System.out.println(alumno.edad());
		System.out.printf("Está viva?: %b", alumno.vive());
		System.out.println();
		//lector.pedir("cargá cualquier número");
		lector.pedir("cargá cualquier número", nacimiento, fallecimiento);
		
		input.close();
	}
}
