package tp1.tp4.tj3;

public class RangoDeEnteros {
	private int limiteInferior;
	private int limiteSuperior;

	public RangoDeEnteros(int limiteInferior, int limiteSuperior) {
		setLimiteInferior(limiteInferior);
		setLimiteSuperior(limiteSuperior);
	}

	private void setLimiteInferior(int limiteInferior) {
		try {			
			if(limiteInferior < this.limiteSuperior || this.limiteSuperior == 0) {
				this.limiteInferior = limiteInferior;			
			} else {
				throw new IllegalArgumentException("Ingreso de datos erróneo");
			}
		} catch(IllegalArgumentException e) {
			System.out.println(e.getMessage());
		}
	}
	
	private void setLimiteSuperior(int limiteSuperior) {
		try {			
			if(limiteSuperior > this.limiteSuperior || this.limiteInferior == 0) {
				this.limiteSuperior = limiteSuperior;			
			} else {
				throw new IllegalArgumentException("Ingreso de datos erróneo");
			}
		} catch(IllegalArgumentException e) {
			System.out.println(e.getMessage());
		}
	}

	public boolean nroAdmitido(int num) {
		return (num >= getLimiteInferior() && num <= getLimiteSuperior());
	}

	public int getLimiteInferior() {
		return this.limiteInferior;
	}
	
	public int getLimiteSuperior() {
		return this.limiteSuperior;
	}
}
