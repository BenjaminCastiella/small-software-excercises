package tp1.tp4.ej2;

import java.util.Scanner;

import tp1.tp4.tj3.LectorEnteros;
import tp1.tp4.tj3.RangoDeEnteros;

public class Ej2 {
	private static Scanner input = new Scanner(System.in);

	public static void main(String[] args) {
		LectorEnteros lector = new LectorEnteros(input);
		final RangoDeEnteros RANGO_ANIO_NACIMIENTO = new RangoDeEnteros(1900, 2019);
		Alumno alu = creadorDeAlumno();		
		
		System.out.println(alu.toString());

		if (alu.vive()) {
			System.out.println("La persona vive");
		} else {
			System.out.println("La persona no vive");
		}

	}
	
	public static Alumno creadorDeAlumno(){
		Alumno newAlu = null;
		String nombreFinal;
		int anioNacimiento = 0;
		int dni = 0;
		
		System.out.println("Ingrese el nombre del alumno");
		nombreFinal = input.nextLine();
		try {
			System.out.println("Ingrese el anio de nacimiento del alumno");
			anioNacimiento = Integer.parseInt(input.nextLine());			
		} catch(NumberFormatException e) {
			System.out.println("Ha cometido el siguiente error: " + e.getMessage());
		}
		try {
			System.out.println("Ingrese el DNI del alumno");
			dni = Integer.parseInt(input.nextLine());					
		} catch(NumberFormatException e) {
			System.out.println("Ha cometido el siguiente error: " + e.getMessage());
		}
		
		newAlu = new Alumno(nombreFinal, anioNacimiento, dni);
		
		input.close();
		return newAlu;
	}
}