package tp1.tp4.ej2;

import tp1.tp4.tj3.RangoDeEnteros;

public class Alumno extends Persona{
	public static final RangoDeEnteros RANGO_NRO_DOCUMENTO = new RangoDeEnteros(1000000, 99999999);
	private int legajo;
	
	public Alumno(String nombre, int anioNacimiento, int dni) {
		super(nombre, anioNacimiento);
		setDocumento(dni);
	}
	
	public Alumno(String nombre, int anioNacimiento, int anioFallecimiento, int dni) {
		super(nombre, anioNacimiento, anioFallecimiento);
		setDocumento(dni);
	}
	
	private void setDocumento(int dni) {
		if(dni < Alumno.RANGO_NRO_DOCUMENTO.getLimiteInferior() || dni > Alumno.RANGO_NRO_DOCUMENTO.getLimiteSuperior()) {
			throw new IllegalArgumentException("El dni no puede estar fuera de rango");
		} else {
			this.legajo = dni;
		}			
	}

	@Override
	public String toString() {
		return "Alumno [" + super.toString() + " legajo=" + legajo + "]";
	}

	
	
}
