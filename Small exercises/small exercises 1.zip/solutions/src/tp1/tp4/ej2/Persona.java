package tp1.tp4.ej2;
import java.time.Year;

public abstract class Persona {
	private static final int VIVE = -9999;
	private static final int VIVE_DOS = -1;
	private String nombre;
	private int anioNacimiento;
	private int anioFallecimiento;
	private static final int ANIO_ACTUAL = Year.now().getValue();

	public Persona(String nombre, int anioNacimiento) {
		setNombre(nombre);
		setAnioNacimiento(anioNacimiento);
		this.anioFallecimiento = VIVE;
	}
	
	public Persona(String nombre, int anioNacimiento, int anioFallecimiento) {
		setNombre(nombre);
		setAnioNacimiento(anioNacimiento);
		setAnioFallecimiento(anioFallecimiento);
	}

	private void setNombre(String nombre) {
		if(nombre.isEmpty() || nombre == null) {
			throw new IllegalArgumentException("El nombre no puede estar vacío");
		} else {
			this.nombre = nombre;			
		}	
		
	}

	private void setAnioNacimiento(int anioNacimiento) {
		if(anioNacimiento > ANIO_ACTUAL || anioNacimiento < 1900) {
			throw new IllegalArgumentException("El anio de nacimiento no puede ser mayor al actual ni menor a 19OO");
		} else {
			this.anioNacimiento = anioNacimiento;
		}
	}

	public void setAnioFallecimiento(int anioFallecimiento) {
		if(anioFallecimiento < this.getAnioNacimiento() && anioFallecimiento != VIVE && anioFallecimiento != VIVE_DOS|| anioFallecimiento > ANIO_ACTUAL) {
			throw new IllegalArgumentException("El anio de fallecimiento no puede ser mayor al anio actual ni menor que el anio de nacimiento");
		} else {
			this.anioFallecimiento = anioFallecimiento;
		}
	}

	public boolean vive() {
		if(this.anioFallecimiento == Persona.VIVE || this.anioFallecimiento == Persona.VIVE_DOS) {
			return true;
		} else {
			return false;
		}
	}
	
	public String edad() {
		int edad = Persona.ANIO_ACTUAL - this.anioNacimiento;
		return "Tiene " + edad;
	}
	
	public String getNombre() {
		return this.nombre;
	}

	public int getAnioNacimiento() {
		return this.anioNacimiento;
	}
	
	public int getAnioFallecimiento() {
		return this.anioFallecimiento;
	}
	
	@Override
	public String toString() {
		return "nombre=" + nombre + ", vive=" + vive() + ", anioNacimiento=" + anioNacimiento
				+ ", anioFallecimiento=" + anioFallecimiento;
	}
	
}
